#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl30/types.h>
#include <glbinding/gl30ext/types.h>
#include <glbinding/gl30/boolean.h>
#include <glbinding/gl30ext/boolean.h>
#include <glbinding/gl30/values.h>
#include <glbinding/gl30ext/values.h>
#include <glbinding/gl30/bitfield.h>
#include <glbinding/gl30ext/bitfield.h>
#include <glbinding/gl30/enum.h>
#include <glbinding/gl30ext/enum.h>
#include <glbinding/gl30/functions.h>
#include <glbinding/gl30ext/functions.h>
