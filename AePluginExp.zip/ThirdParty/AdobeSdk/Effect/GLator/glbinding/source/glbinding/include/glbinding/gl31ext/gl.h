#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl31ext/types.h>
#include <glbinding/gl31ext/boolean.h>
#include <glbinding/gl31ext/values.h>
#include <glbinding/gl31ext/bitfield.h>
#include <glbinding/gl31ext/enum.h>
#include <glbinding/gl31ext/functions.h>
